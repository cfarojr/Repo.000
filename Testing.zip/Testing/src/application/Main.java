package application;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;

public class Main extends Application {
	// Class to sort freqMap
	public static HashMap<String, Integer> sortByValue(HashMap<String, Integer> freqMap) {
		List<Map.Entry<String, Integer> > list =
			new LinkedList<Map.Entry<String, Integer> >(freqMap.entrySet());

		Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() {
			public int compare(Map.Entry<String, Integer> x, Map.Entry<String, Integer> y) {
				return (y.getValue()).compareTo(x.getValue());
			}
		});

		HashMap<String, Integer> temp = new LinkedHashMap<String, Integer>();
		for (Map.Entry<String, Integer> aa : list) {
			temp.put(aa.getKey(), aa.getValue());
		}
		return temp;
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("Text Analyzer");
		Stage poemStage = new Stage();
		poemStage.setTitle("Poem");
		Stage wordsStage = new Stage();
		wordsStage.setTitle("Word Occurrences");

		// Declare button variables
		Button display = new Button("Display Poem");
		Button analyzer = new Button("Display Word Occurrences");

		VBox menuBox = new VBox(display, analyzer);
		menuBox.setSpacing(10);
		menuBox.setAlignment(Pos.CENTER);



		// App --------------------------------------------------------------------------------------------------------
			// Declare variables
			URL raven = new URL("https://www.gutenberg.org/files/1065/1065-h/1065-h.htm");
			BufferedReader in = new BufferedReader(new InputStreamReader(raven.openStream()));
			String inputLine;
			String poemWords = "";
			String poem = "";
			String words = "";
			boolean read = false;

			while ((inputLine = in.readLine()) != null) {
				// Ignore all HTML tags
				inputLine = inputLine.replaceAll("<P CLASS=\"poem\">", " ");
				inputLine = inputLine.replaceAll("\\<[^>]*>", "");
				inputLine = inputLine.replaceAll(";", "");
				inputLine = inputLine.replaceAll("&mdash", "�");
				inputLine = inputLine.replaceAll("“", "\"");
				inputLine = inputLine.replaceAll("’", "\"");
				inputLine = inputLine.replaceAll("�?", "\"");


				// Ignore all text before the poem's title ----------------
					if (!inputLine.equals("The Raven") && read == false) {
						continue;
					}
					if (inputLine.contains("The Raven")) {
						read = true;
					}
					if (inputLine.isEmpty()) {
						continue;
					}
				//---------------------------------------------------------

				// Ignore all text after the end of the poem
				if (inputLine.contains("*** END OF THE PROJECT GUTENBERG EBOOK THE RAVEN ***")) {
					break;
				}

				// Output the poem
				System.out.println(inputLine);

				// Return poem to String 'poem'
				poemWords += inputLine + " ";
				poem += inputLine + "\n";
			}

			// Ignore all non-letter characters
			poemWords = poemWords.replaceAll("�", " ");
			poemWords = poemWords.replaceAll("[^a-zA-Z ]", "");

			// Analyze frequencies of all words -----------------------------------
				String[] array = poemWords.split(" ");
				HashMap<String, Integer> freqMap = new HashMap<String, Integer>();
				for (int i = 0; i < array.length; i ++) {
					String key = array[i];
					int freq = freqMap.getOrDefault(key, 0);
					freqMap.put(key, ++freq);
				}
			//---------------------------------------------------------------------

			// Sort word frequencies ----------------------------------------------------------------------------------
				Map<String, Integer> sortedFreqMap = sortByValue(freqMap);

				for (Map.Entry<String, Integer> result : sortedFreqMap.entrySet()) {
					if (!result.getKey().isEmpty()) {
						if (result.getValue() == 1) {
							System.out.println("\"" + result.getKey() + "\" - " + result.getValue() + " occurrence");
							words += ("\"" + result.getKey() + "\" - " + result.getValue() + " occurrence") + "\n";
						} else if (result.getValue() > 1) {
							System.out.println("\"" + result.getKey() + "\" - " + result.getValue() + " occurrences");
							words += ("\"" + result.getKey() + "\" - " + result.getValue() + " occurrences") + "\n";
						}
					}
				}
			//---------------------------------------------------------------------------------------------------------

			// Close BufferedReader
			in.close();
		//-------------------------------------------------------------------------------------------------------------



		// Create scroll panes
		ScrollPane poemPane = new ScrollPane();
		poemPane.setContent(new Label(poem));
		ScrollPane wordsPane = new ScrollPane();
		wordsPane.setContent(new Label(words));

		// Create scenes
		Scene menuScene = new Scene(menuBox, 237, 80);
		Scene poemScene = new Scene(poemPane, 439, 400);
		Scene wordsScene = new Scene(wordsPane, 266, 346);

		// Display main window
		primaryStage.setScene(menuScene);
		primaryStage.show();

		// Declare button actions ---------------
			display.setOnAction(e -> {
				poemStage.setScene(poemScene);
				poemStage.show();
			});
			analyzer.setOnAction(e -> {
				wordsStage.setScene(wordsScene);
				wordsStage.show();
			});
		//---------------------------------------
	}


	// TEST ----------------------------------------------------------------------------------
	public static String poemTest(URL raven) throws Exception {
		BufferedReader in = new BufferedReader(new InputStreamReader(raven.openStream()));
		String inputLine;
		String poem = "";
		boolean read = false;

		while ((inputLine = in.readLine()) != null) {
			// Ignore all HTML tags
			inputLine = inputLine.replaceAll("<P CLASS=\"poem\">", " ");
			inputLine = inputLine.replaceAll("\\<[^>]*>", "");
			inputLine = inputLine.replaceAll(";", "");
			inputLine = inputLine.replaceAll("&mdash", "�");
			inputLine = inputLine.replaceAll("“", "\"");
			inputLine = inputLine.replaceAll("’", "\"");
			inputLine = inputLine.replaceAll("�?", "\"");


			// Ignore all text before the poem's title ----------------
				if (!inputLine.equals("The Raven") && read == false) {
					continue;
				}
				if (inputLine.contains("The Raven")) {
					read = true;
				}
				if (inputLine.isEmpty()) {
					continue;
				}
			//---------------------------------------------------------

			// Ignore all text after the end of the poem
			if (inputLine.contains("*** END OF THE PROJECT GUTENBERG EBOOK THE RAVEN ***")) {
				break;
			}

			// Return poem to String 'poem'
			poem += inputLine + "\n";
		}
		// Return the poem
		return poem;
	}
	//----------------------------------------------------------------------------------------


	public static void main(String[] args) throws Exception {
		launch(args);

		// TEST
		URL raven = new URL("https://www.gutenberg.org/files/1065/1065-h/1065-h.htm");
		poemTest(raven);
	}
}
