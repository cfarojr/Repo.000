package application;


import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import org.junit.Test;

/**
 * <h2>MainTest</h2>
 * The MainTest class tests the main features of the Word
 * Occurrences application via JUnit.
 * <p>
 * @author Christopher Faro
 */
public class MainTest {
	@Test
	public void test() throws Exception {
		// Declare variable
		URL raven = new URL("https://www.gutenberg.org/files/1065/1065-h/1065-h.htm");

		// Poem ------------------------------------------------------------------------------
		BufferedReader in = new BufferedReader(new InputStreamReader(raven.openStream()));
		String inputLine;
		String poem = "";
		boolean read = false;

		while ((inputLine = in.readLine()) != null) {
			// Ignore all HTML tags
			inputLine = inputLine.replaceAll("<P CLASS=\"poem\">", " ");
			inputLine = inputLine.replaceAll("\\<[^>]*>", "");
			inputLine = inputLine.replaceAll(";", "");
			inputLine = inputLine.replaceAll("&mdash", "�");
			inputLine = inputLine.replaceAll("“", "\"");
			inputLine = inputLine.replaceAll("’", "\"");
			inputLine = inputLine.replaceAll("�?", "\"");


			// Ignore all text before the poem's title ----------------
				if (!inputLine.equals("The Raven") && read == false) {
					continue;
				}
				if (inputLine.contains("The Raven")) {
					read = true;
				}
				if (inputLine.isEmpty()) {
					continue;
				}
			//---------------------------------------------------------

			// Ignore all text after the end of the poem
			if (inputLine.contains("*** END OF THE PROJECT GUTENBERG EBOOK THE RAVEN ***")) {
				break;
			}

			// Return poem to String 'poem'
			poem += inputLine + "\n";
		}
		//------------------------------------------------------------------------------------

		// Output the poem
		System.out.println(poem);

		// TEST
		assertEquals(poem, Client.poemTest(raven));
	}
}
