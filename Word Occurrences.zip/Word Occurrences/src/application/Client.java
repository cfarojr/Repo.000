package application;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.sql.*;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;

/**
 * <h1>Word Occurrences</h1>
 * The Word Occurrences application "reads a file and
 * outputs... the word frequencies of all words in the file,
 * sorted by the most frequently used word."
 * <p>
 * @author Christopher Faro
 * @version 1.6
 */

public class Client extends Application {
	// IO streams
	DataOutputStream toServer = null;
	DataInputStream fromServer = null;
	/**
	 * <h3>start</h3>
	 * The start method performs the main features of the Word
	 * Occurrences application via UI.
	 * <p>
	 * @param primaryStage
	 * @throws Exception
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("Client");
		Stage poemStage = new Stage();
		poemStage.setTitle("Poem");
		Stage wordsStage = new Stage();
		wordsStage.setTitle("Word Occurrences");

		// Declare button variables
		Button display = new Button("Display Poem");
		Button analyzer = new Button("Display Word Occurrences");

		VBox menuBox = new VBox(display, analyzer);
		menuBox.setSpacing(10);
		menuBox.setAlignment(Pos.CENTER);



		// App --------------------------------------------------------------------------------------------------------
			// Declare variables
			URL raven = new URL("https://www.gutenberg.org/files/1065/1065-h/1065-h.htm");
			BufferedReader in = new BufferedReader(new InputStreamReader(raven.openStream()));
			String inputLine;
			String poemWords = "";
			String poem = "";
			String wordsLabel = "";
			boolean read = false;

			while ((inputLine = in.readLine()) != null) {
				// Ignore all HTML tags
				inputLine = inputLine.replaceAll("<P CLASS=\"poem\">", " ");
				inputLine = inputLine.replaceAll("\\<[^>]*>", "");
				inputLine = inputLine.replaceAll(";", "");
				inputLine = inputLine.replaceAll("&mdash", "�");
				inputLine = inputLine.replaceAll("“", "\"");
				inputLine = inputLine.replaceAll("’", "\"");
				inputLine = inputLine.replaceAll("�?", "\"");


				// Ignore all text before the poem's title ----------------
					if (!inputLine.equals("The Raven") && read == false) {
						continue;
					}
					if (inputLine.contains("The Raven")) {
						read = true;
					}
					if (inputLine.isEmpty()) {
						continue;
					}
				//---------------------------------------------------------

				// Ignore all text after the end of the poem
				if (inputLine.contains("*** END OF THE PROJECT GUTENBERG EBOOK THE RAVEN ***")) {
					break;
				}

				// Output the poem
				System.out.println(inputLine);

				// Return poem to String 'poem'
				poemWords += inputLine + " ";
				poem += inputLine + "\n";
			}

			// Ignore all non-letter characters
			poemWords = poemWords.replaceAll("�", " ");
			poemWords = poemWords.replaceAll("[^a-zA-Z ]", "");


			// Connect to MySQL, analyze word frequencies, and store data in MySQL -----------------------------------------------------------
			try {
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/word occurrences?autoReconnect=true&useSSL=false",
															  "root",
															  "cfaro_MySQL_pwd_7094");
				String[] array = poemWords.split(" ");
				PreparedStatement pstmt = conn.prepareStatement("INSERT IGNORE INTO word(idword, occurrences) VALUES(?, ?)");
				for (int i = 0; i < array.length; i ++) {
					String key = array[i];

					int count = poemWords.split("\\b" + key + "\\b").length - 1;
					if(!key.isEmpty()) {
						pstmt.setString(1, key);
						pstmt.setInt(2, count);
						pstmt.executeUpdate();
					}
				}

				Statement selectStmt = conn.createStatement();
				ResultSet rs = selectStmt.executeQuery("SELECT * FROM word ORDER BY occurrences DESC");
				while (rs.next()) {
					if(rs.getInt("occurrences") == 1) {
						System.out.println("\"" + rs.getString("idword") + "\" - " + rs.getInt("occurrences") + " occurrence");
						wordsLabel += ("\"" + rs.getString("idword") + "\" - " + rs.getInt("occurrences") + " occurrence\n");
					} else if (rs.getInt("occurrences") > 1) {
						System.out.println("\"" + rs.getString("idword") + "\" - " + rs.getInt("occurrences") + " occurrences");
						wordsLabel += ("\"" + rs.getString("idword") + "\" - " + rs.getInt("occurrences") + " occurrences\n");
					}
				}

				rs.close();

			} catch(Exception e) {
				System.out.println(e);
			}

			// Close BufferedReader
			in.close();
			//--------------------------------------------------------------------------------------------------------------------------------



		// Create scroll panes
		ScrollPane poemPane = new ScrollPane();
		poemPane.setContent(new Label(poem));
		//ScrollPane wordsPane = new ScrollPane();
		//wordsPane.setContent(new Label(wordsLabel));

		// Create scenes
		Scene menuScene = new Scene(menuBox, 237, 80);
		Scene poemScene = new Scene(poemPane, 439, 400);
		//Scene wordsScene = new Scene(wordsPane, 266, 346);

		// Display main window
		primaryStage.setScene(menuScene);
		primaryStage.show();

		final String serverWords = wordsLabel;
		// Declare button actions ---------------
			display.setOnAction(e -> {
				poemStage.setScene(poemScene);
				poemStage.show();
			});
			analyzer.setOnAction(e -> {
				//wordsStage.setScene(wordsScene);
				//wordsStage.show();
				try {
					toServer.writeUTF(serverWords);
					toServer.flush();
				} catch (IOException ex) {
					System.err.println(ex);
				}
			});
		//---------------------------------------
		try {
			// Create a socket to connect to the server
			Socket socket = new Socket("localhost", 8000);

			// Create input and output streams to send and receive data from the server
			fromServer = new DataInputStream(socket.getInputStream());
			toServer = new DataOutputStream(socket.getOutputStream());
		}
		catch (IOException ex) {
			System.err.println(ex);
		}
	}


	// TEST ----------------------------------------------------------------------------------
	/**
	 * <h3>poemTest</h3>
	 * The poemTest method displays the poem in the Console.
	 * <p>
	 * @param raven
	 * @return poem
	 * @throws Exception
	 */
	public static String poemTest(URL raven) throws Exception {
		BufferedReader in = new BufferedReader(new InputStreamReader(raven.openStream()));
		String inputLine;
		String poem = "";
		boolean read = false;

		while ((inputLine = in.readLine()) != null) {
			// Ignore all HTML tags
			inputLine = inputLine.replaceAll("<P CLASS=\"poem\">", " ");
			inputLine = inputLine.replaceAll("\\<[^>]*>", "");
			inputLine = inputLine.replaceAll(";", "");
			inputLine = inputLine.replaceAll("&mdash", "�");
			inputLine = inputLine.replaceAll("“", "\"");
			inputLine = inputLine.replaceAll("’", "\"");
			inputLine = inputLine.replaceAll("�?", "\"");


			// Ignore all text before the poem's title ----------------
				if (!inputLine.equals("The Raven") && read == false) {
					continue;
				}
				if (inputLine.contains("The Raven")) {
					read = true;
				}
				if (inputLine.isEmpty()) {
					continue;
				}
			//---------------------------------------------------------

			// Ignore all text after the end of the poem
			if (inputLine.contains("*** END OF THE PROJECT GUTENBERG EBOOK THE RAVEN ***")) {
				break;
			}

			// Return poem to String 'poem'
			poem += inputLine + "\n";
		}
		// Return the poem
		return poem;
	}
	//----------------------------------------------------------------------------------------


	public static void main(String[] args) throws Exception {
		launch(args);

		// TEST
		//URL raven = new URL("https://www.gutenberg.org/files/1065/1065-h/1065-h.htm");
		//System.out.println(poemTest(raven));
	}
}
