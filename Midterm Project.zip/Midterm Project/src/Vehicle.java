import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public abstract class Vehicle extends Thread implements Runnable {
	private String make;
	private String model;
	private int lap;
	private int speed;
	
	private boolean winner = false;
	
	public static boolean finish = false;
	private static int finalLap = 500;
	Random rnd = new Random();
	
	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy  HH:mm:ss");
	Date date = new Date();
	
	public Vehicle() {}
	
	public Vehicle(String brand, String type, int position) {
		this.make = brand;
		this.model = type;
		this.lap = position;
	}
	
	//make getter and setter
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	
	//model getter and setter
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	//lap getter and setter
	public int getLap() {
		return lap;
	}
	public void setLap(int lap) {
		this.lap = lap;
	}
	
	//speed getter and setter
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	//winner getter and setter
		public boolean getWinner() {
			return winner;
		}
		public void setWinner(boolean winner) {
			this.winner = winner;
		}
	
	@Override
	public void run() {
		while(this.lap < finalLap && finish == false) {
			try {
				long pitStop = rnd.nextInt(2000);
				Vehicle.sleep(pitStop);
				this.lap += this.getSpeed();
				System.out.println(this.getMake() + this.getModel() + " is on Lap " + this.lap);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		if(this.lap >= finalLap && finish == false) {
			finish = true;
			this.winner = true;
			System.out.println("Finish!");
			System.out.println(this.getMake() + this.getModel() + " Wins");
			
			
			//Create file
			try {
				File obj = new File("Results.txt");
				if(obj.createNewFile()) {
					System.out.println("File successfully created: " + obj.getName());
				}
				else {
					System.out.println("File already exists.");
				}
			}
			catch (IOException e) {
				System.out.println("An error has occurred.");
				e.printStackTrace();
			}
			
			//Write to file
			try {
				FileWriter writer = new FileWriter("Results.txt");
				writer.write(this.getMake() + " " + this.getModel() + " won on " + dateFormat.format(date));
				writer.close();
				System.out.println("Successfully wrote to file.");
			}
			catch (IOException e) {
				System.out.println("An error has occurred.");
				e.printStackTrace();
			}
			
			
			System.exit(0);
		}
	}
}
