
public class App {
	public static void main(String[] args) {
		Motorcycle superCub = new Motorcycle("Honda", "Super Cub", 0);
		Sedan crownVic = new Sedan("Ford", "Crown Victoria", 0);
		Truck ram = new Truck("Dodge", "Ram", 0);
		
		superCub.setDaemon(false);
		crownVic.setDaemon(false);
		ram.setDaemon(false);
		
		superCub.start();
		crownVic.start();
		ram.start();
		
		//System.out.println(superCub.getMake() + " " + superCub.getModel() + " Top Speed: " + superCub.getSpeed() + "mph");
		//System.out.println(crownVic.getMake() + " " + crownVic.getModel() + " Top Speed: " + crownVic.getSpeed() + "mph");
		//System.out.println(ram.getMake() + " " + ram.getModel() + " Top Speed: " + ram.getSpeed() + "mph");
	}
}
