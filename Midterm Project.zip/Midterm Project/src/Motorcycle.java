
public class Motorcycle extends Vehicle {
private int speed;
	
	public Motorcycle(String make, String model, int lap) {
		super(make, model, lap);
		this.speed = 100;
	}
	
	public Motorcycle(String make, String model, int lap, int speed) {
		super(make, model, lap);
		this.speed = speed;
	}
	
	//speed getter and setter
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
}
