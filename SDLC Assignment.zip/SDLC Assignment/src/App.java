import java.io.*;
import java.net.*;
import java.util.*;

public class App {
	// Class to sort freqMap
	public static HashMap<String, Integer> sortByValue(HashMap<String, Integer> freqMap)
    {
        List<Map.Entry<String, Integer> > list =
               new LinkedList<Map.Entry<String, Integer> >(freqMap.entrySet());

        Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() {
            public int compare(Map.Entry<String, Integer> x, Map.Entry<String, Integer> y) {
                return (y.getValue()).compareTo(x.getValue());
            }
        });

        HashMap<String, Integer> temp = new LinkedHashMap<String, Integer>();
        for (Map.Entry<String, Integer> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }

	public static void main(String[] args) throws Exception {
		// Declare variables
		URL raven = new URL("https://www.gutenberg.org/files/1065/1065-h/1065-h.htm");
		BufferedReader in = new BufferedReader(new InputStreamReader(raven.openStream()));
		String inputLine;
		String poem = "";
		boolean read = false;

		while ((inputLine = in.readLine()) != null) {
			// Ignore all HTML tags
			inputLine = inputLine.replaceAll("<P CLASS=\"poem\">", " ");
			inputLine = inputLine.replaceAll("\\<[^>]*>", "");
			inputLine = inputLine.replaceAll(";", "");
			inputLine = inputLine.replaceAll("&mdash", "�");

			// Ignore all text before the poem's title ----------------
				if (!inputLine.equals("The Raven") && read == false) {
					continue;
				}
				if (inputLine.contains("The Raven")) {
					read = true;
				}
				if (inputLine.isEmpty()) {
					continue;
				}
			//---------------------------------------------------------

			// Ignore all text after the end of the poem
			if (inputLine.contains("End of the Project Gutenberg EBook of The Raven, by Edgar Allan Poe")) {
				break;
			}

			// Output the poem
			System.out.println(inputLine);

			// Return poem to String 'poem'
			poem += " " + inputLine;
		}

		// Ignore all non-letter characters
		poem = poem.replaceAll("�", " ");
		poem = poem.replaceAll("[^a-zA-Z ]", "");

		// Analyze frequencies of all words ------------------------------------
			String[] array = poem.split(" ");
			HashMap<String, Integer> freqMap = new HashMap<String, Integer>();
			for (int i = 0; i < array.length; i ++) {
				String key = array[i];
				int freq = freqMap.getOrDefault(key, 0);
				freqMap.put(key, ++freq);
			}
		//----------------------------------------------------------------------

		// Sort word frequencies -----------------------------------------------
			Map<String, Integer> sortedFreqMap = sortByValue(freqMap);

			for (Map.Entry<String, Integer> result : sortedFreqMap.entrySet()) {
				if (!result.getKey().isEmpty()) {
					if (result.getValue() == 1) {
						System.out.println("\"" + result.getKey() + "\" - " + result.getValue() + " occurrence");
					} else if (result.getValue() > 1) {
						System.out.println("\"" + result.getKey() + "\" - " + result.getValue() + " occurrences");
					}
				}
			}
		//----------------------------------------------------------------------

		// Close BufferedReader
		in.close();
	}
}
