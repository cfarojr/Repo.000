import java.util.Scanner;

public class App {

	public static int recursiveFibonacci(int n) { // Recursive Fibonacci function

		// If-else statements to run sequence ---------------------------------------------------
		if (n ==0) {
			return 0;
		} else if (n == 1) {
			return 1;
		}
		//---------------------------------------------------------------------------------------

		return (recursiveFibonacci(n - 1) + recursiveFibonacci(n - 2)); // Returns the current number in the sequence
	}

	public static String iterativeFibonacci(int n) { // Iterative Fibonacci function

		long startTime = System.nanoTime(); // Start the iterative runtime clock
		int prev2x, prev = 0, curr = 1; // Declares variables for the previous two numbers in the sequence and their sum

		// For loop to run sequence --
		for (int i = 1; i < n; i++) {
			prev2x = prev;
			prev = curr;
			curr = prev2x + prev;
		}
		//----------------------------

		return ("The " + n + "th number in the [iterative] Fibonacci sequence is " + curr + " (Runtime: " + (System.nanoTime() - startTime) + ")"); // Returns the current number in the sequence
	}

	public static void main(String[] args) { // Main function

		// Declare variables and get value to start sequence -------------------------
		Scanner in = new Scanner(System.in);
		System.out.println("Please enter a number to start the Fibonacci sequence.");
		int n = in.nextInt();
		//----------------------------------------------------------------------------

		long startTime = System.nanoTime(); // Start the recursive runtime clock

		// Display Fibonacci number based on user-given value ------------------------------------------------------------------------------------------------------------------
		System.out.println("The " + n + "th number in the [recursive] Fibonacci sequence is " + recursiveFibonacci(n) + " (Runtime: " + (System.nanoTime() - startTime) + ")");
		System.out.println(iterativeFibonacci(n));
		//----------------------------------------------------------------------------------------------------------------------------------------------------------------------

		in.close(); // Closes previously declared/opened Scanner "in"
	}
}
