import java.util.Arrays;
import java.util.Random;

public class App {
	public static void main(String[] args) {
		// Multi-thread -------------------------------------------------------------------------------------------------
			// Declare variables
			double startTime1 = System.currentTimeMillis();
				//Instantiate array and sum via parallel streams
				int[] array1 = new Random().ints(200000000, 1, 10).toArray();
				int sum1 = Arrays.stream(array1).parallel().sum();

			// Display results
			System.out.print("Multi-Thread (Parallel Streams): \n" +
							 "    Sum = " + sum1 + "\n" +
							 "    Runtime: " + ((System.currentTimeMillis() - startTime1) / 1000.000) + " seconds\n\n");
		//---------------------------------------------------------------------------------------------------------------

		// Single thread ----------------------------------------------------------------------------------------
			// Declare Variables
			double startTime2 = System.currentTimeMillis();
			int[] array2 = new int[200000000];
			int sum2 = 0;

			// Fill array
			for(int i = 0; i < array2.length; i++) {
				array2[i] = (int)(Math.random() * 10);
				sum2 += array2[i];
			}
			// Display results
			System.out.print("Single Thread (for Loop): \n" +
							 "    Sum = " + sum2 + "\n" +
							 "    Runtime: " + ((System.currentTimeMillis() - startTime2) / 1000) + " seconds");
		//-------------------------------------------------------------------------------------------------------
	}
}
